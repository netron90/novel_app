--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.10
-- Dumped by pg_dump version 9.6.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: _auth_group; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._auth_group (
    id character varying(1) DEFAULT NULL::character varying,
    name character varying(1) DEFAULT NULL::character varying
);


ALTER TABLE public._auth_group OWNER TO rebasedata;

--
-- Name: _auth_group_permissions; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._auth_group_permissions (
    id character varying(1) DEFAULT NULL::character varying,
    group_id character varying(1) DEFAULT NULL::character varying,
    permission_id character varying(1) DEFAULT NULL::character varying
);


ALTER TABLE public._auth_group_permissions OWNER TO rebasedata;

--
-- Name: _auth_permission; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._auth_permission (
    id smallint,
    content_type_id smallint,
    codename character varying(18) DEFAULT NULL::character varying,
    name character varying(23) DEFAULT NULL::character varying
);


ALTER TABLE public._auth_permission OWNER TO rebasedata;

--
-- Name: _django_admin_log; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._django_admin_log (
    id smallint,
    object_id smallint,
    object_repr character varying(20) DEFAULT NULL::character varying,
    action_flag smallint,
    change_message character varying(225) DEFAULT NULL::character varying,
    content_type_id smallint,
    user_id smallint,
    action_time character varying(10) DEFAULT NULL::character varying
);


ALTER TABLE public._django_admin_log OWNER TO rebasedata;

--
-- Name: _django_content_type; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._django_content_type (
    id smallint,
    app_label character varying(12) DEFAULT NULL::character varying,
    model character varying(11) DEFAULT NULL::character varying
);


ALTER TABLE public._django_content_type OWNER TO rebasedata;

--
-- Name: _django_migrations; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._django_migrations (
    id smallint,
    app character varying(12) DEFAULT NULL::character varying,
    name character varying(61) DEFAULT NULL::character varying,
    applied character varying(10) DEFAULT NULL::character varying
);


ALTER TABLE public._django_migrations OWNER TO rebasedata;

--
-- Name: _django_session; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._django_session (
    session_key character varying(32) DEFAULT NULL::character varying,
    session_data character varying(227) DEFAULT NULL::character varying,
    expire_date character varying(10) DEFAULT NULL::character varying
);


ALTER TABLE public._django_session OWNER TO rebasedata;

--
-- Name: _novel_category; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._novel_category (
    id smallint,
    name character varying(11) DEFAULT NULL::character varying
);


ALTER TABLE public._novel_category OWNER TO rebasedata;

--
-- Name: _novel_category_town; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._novel_category_town (
    id smallint,
    category_id smallint,
    town_id smallint
);


ALTER TABLE public._novel_category_town OWNER TO rebasedata;

--
-- Name: _novel_country; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._novel_country (
    id smallint,
    name character varying(7) DEFAULT NULL::character varying
);


ALTER TABLE public._novel_country OWNER TO rebasedata;

--
-- Name: _novel_novel; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._novel_novel (
    id smallint,
    name character varying(20) DEFAULT NULL::character varying,
    brief_description character varying(32) DEFAULT NULL::character varying,
    description character varying(323) DEFAULT NULL::character varying,
    status smallint,
    date_start character varying(1) DEFAULT NULL::character varying,
    date_end character varying(1) DEFAULT NULL::character varying,
    category_id smallint,
    country_id smallint,
    town_id smallint,
    location character varying(24) DEFAULT NULL::character varying,
    mail_contact character varying(25) DEFAULT NULL::character varying,
    phone_contact character varying(16) DEFAULT NULL::character varying,
    novel_number character varying(16) DEFAULT NULL::character varying,
    number smallint
);


ALTER TABLE public._novel_novel OWNER TO rebasedata;

--
-- Name: _novel_novelimage; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._novel_novelimage (
    id smallint,
    "interval" integer,
    novel_id smallint,
    image_url character varying(19) DEFAULT NULL::character varying
);


ALTER TABLE public._novel_novelimage OWNER TO rebasedata;

--
-- Name: _novel_town; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._novel_town (
    id smallint,
    name character varying(10) DEFAULT NULL::character varying,
    country_id smallint
);


ALTER TABLE public._novel_town OWNER TO rebasedata;

--
-- Name: _novel_user; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._novel_user (
    id smallint,
    password character varying(88) DEFAULT NULL::character varying,
    last_login character varying(10) DEFAULT NULL::character varying,
    is_superuser smallint,
    username character varying(8) DEFAULT NULL::character varying,
    first_name character varying(1) DEFAULT NULL::character varying,
    last_name character varying(1) DEFAULT NULL::character varying,
    email character varying(20) DEFAULT NULL::character varying,
    is_staff smallint,
    is_active smallint,
    date_joined character varying(10) DEFAULT NULL::character varying,
    wallet smallint
);


ALTER TABLE public._novel_user OWNER TO rebasedata;

--
-- Name: _novel_user_groups; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._novel_user_groups (
    id character varying(1) DEFAULT NULL::character varying,
    user_id character varying(1) DEFAULT NULL::character varying,
    group_id character varying(1) DEFAULT NULL::character varying
);


ALTER TABLE public._novel_user_groups OWNER TO rebasedata;

--
-- Name: _novel_user_user_permissions; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._novel_user_user_permissions (
    id character varying(1) DEFAULT NULL::character varying,
    user_id character varying(1) DEFAULT NULL::character varying,
    permission_id character varying(1) DEFAULT NULL::character varying
);


ALTER TABLE public._novel_user_user_permissions OWNER TO rebasedata;

--
-- Name: _sqlite_sequence; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._sqlite_sequence (
    name character varying(19) DEFAULT NULL::character varying,
    seq smallint
);


ALTER TABLE public._sqlite_sequence OWNER TO rebasedata;

--
-- Data for Name: _auth_group; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: _auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: _auth_permission; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._auth_permission (id, content_type_id, codename, name) FROM stdin;
1	1	add_category	Can add category
2	1	change_category	Can change category
3	1	delete_category	Can delete category
4	1	view_category	Can view category
5	2	add_country	Can add country
6	2	change_country	Can change country
7	2	delete_country	Can delete country
8	2	view_country	Can view country
9	3	add_user	Can add user
10	3	change_user	Can change user
11	3	delete_user	Can delete user
12	3	view_user	Can view user
13	4	add_town	Can add town
14	4	change_town	Can change town
15	4	delete_town	Can delete town
16	4	view_town	Can view town
17	5	add_novel	Can add novel
18	5	change_novel	Can change novel
19	5	delete_novel	Can delete novel
20	5	view_novel	Can view novel
21	6	add_logentry	Can add log entry
22	6	change_logentry	Can change log entry
23	6	delete_logentry	Can delete log entry
24	6	view_logentry	Can view log entry
25	7	add_permission	Can add permission
26	7	change_permission	Can change permission
27	7	delete_permission	Can delete permission
28	7	view_permission	Can view permission
29	8	add_group	Can add group
30	8	change_group	Can change group
31	8	delete_group	Can delete group
32	8	view_group	Can view group
33	9	add_contenttype	Can add content type
34	9	change_contenttype	Can change content type
35	9	delete_contenttype	Can delete content type
36	9	view_contenttype	Can view content type
37	10	add_session	Can add session
38	10	change_session	Can change session
39	10	delete_session	Can delete session
40	10	view_session	Can view session
41	11	add_novelimage	Can add novel image
42	11	change_novelimage	Can change novel image
43	11	delete_novelimage	Can delete novel image
44	11	view_novelimage	Can view novel image
\.


--
-- Data for Name: _django_admin_log; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._django_admin_log (id, object_id, object_repr, action_flag, change_message, content_type_id, user_id, action_time) FROM stdin;
1	1	Bénin	1	[{"added": {}}]	2	1	2024-06-14
2	2	Togo	1	[{"added": {}}]	2	1	2024-06-14
3	3	Nigéria	1	[{"added": {}}]	2	1	2024-06-14
4	1	Cotonou	1	[{"added": {}}]	4	1	2024-06-14
5	2	Porto-Novo	1	[{"added": {}}]	4	1	2024-06-14
6	3	Calavi	1	[{"added": {}}]	4	1	2024-06-14
7	4	Lomé	1	[{"added": {}}]	4	1	2024-06-14
8	5	Sokodé	1	[{"added": {}}]	4	1	2024-06-14
9	6	Kara	1	[{"added": {}}]	4	1	2024-06-14
10	7	Lagos	1	[{"added": {}}]	4	1	2024-06-14
11	8	Abuja	1	[{"added": {}}]	4	1	2024-06-14
12	9	Kano	1	[{"added": {}}]	4	1	2024-06-14
13	1	Jobs	1	[{"added": {}}]	1	1	2024-06-14
14	2	Location	1	[{"added": {}}]	1	1	2024-06-14
15	3	Services	1	[{"added": {}}]	1	1	2024-06-14
16	4	A vendre	1	[{"added": {}}]	1	1	2024-06-14
17	5	Evénnements	1	[{"added": {}}]	1	1	2024-06-14
18	6	Nourritures	1	[{"added": {}}]	1	1	2024-06-14
19	1	Novel object (1)	1	[{"added": {}}]	5	1	2024-06-14
20	2	Novel object (2)	1	[{"added": {}}]	5	1	2024-06-14
21	3	Novel object (3)	1	[{"added": {}}]	5	1	2024-06-14
22	4	Novel object (4)	1	[{"added": {}}]	5	1	2024-06-14
23	5	Novel object (5)	1	[{"added": {}}]	5	1	2024-06-14
24	6	Novel object (6)	1	[{"added": {}}]	5	1	2024-06-14
25	5	Evénnements	2	[{"changed": {"fields": ["Town"]}}]	1	1	2024-06-14
26	1	Jobs	2	[]	1	1	2024-06-14
27	3	Novel object (3)	2	[{"changed": {"fields": ["Country"]}}]	5	1	2024-06-14
28	7	Novel object (7)	1	[{"added": {}}]	5	1	2024-06-14
29	3	Novel object (3)	2	[{"changed": {"fields": ["Image url"]}}]	5	1	2024-06-14
30	1	Novel object (1)	2	[{"changed": {"fields": ["Image url"]}}]	5	1	2024-06-14
31	2	Novel object (2)	2	[{"changed": {"fields": ["Image url"]}}]	5	1	2024-06-14
32	4	Novel object (4)	2	[{"changed": {"fields": ["Image url"]}}]	5	1	2024-06-14
33	5	Novel object (5)	2	[{"changed": {"fields": ["Image url"]}}]	5	1	2024-06-14
34	6	Novel object (6)	2	[{"changed": {"fields": ["Image url"]}}]	5	1	2024-06-14
35	7	Novel object (7)	2	[{"changed": {"fields": ["Image url"]}}]	5	1	2024-06-14
36	5	Novel object (5)	2	[{"changed": {"fields": ["Town"]}}]	5	1	2024-06-14
37	1	Novel object (1)	2	[{"changed": {"fields": ["Location", "Mail contact"]}}]	5	1	2024-06-17
38	2	Novel object (2)	2	[{"changed": {"fields": ["Location", "Mail contact"]}}]	5	1	2024-06-17
39	3	Novel object (3)	2	[{"changed": {"fields": ["Location", "Mail contact"]}}]	5	1	2024-06-17
40	4	Novel object (4)	2	[{"changed": {"fields": ["Location", "Mail contact"]}}]	5	1	2024-06-17
41	5	Novel object (5)	2	[{"changed": {"fields": ["Location", "Mail contact"]}}]	5	1	2024-06-17
42	6	Novel object (6)	2	[{"changed": {"fields": ["Location", "Mail contact"]}}]	5	1	2024-06-17
43	7	Novel object (7)	2	[{"changed": {"fields": ["Location", "Mail contact"]}}]	5	1	2024-06-17
44	8	KOKOJOB	1	[{"added": {}}]	5	2	2024-07-01
45	1	Novel object (1)	2	[{"changed": {"fields": ["Status"]}}]	5	2	2024-07-01
46	1	Novel object (1)	2	[{"changed": {"fields": ["Status", "Date end"]}}]	5	2	2024-07-01
47	1	Entreprise SARL	3		5	2	2024-07-01
48	2	JOJO Company	3		5	2	2024-07-01
49	9	Entreprise SARL	1	[{"added": {}}]	5	2	2024-07-01
50	9	Entreprise SARL	2	[{"changed": {"fields": ["Image url"]}}]	5	2	2024-07-01
51	8	KOKOJOB	2	[{"changed": {"fields": ["Image url"]}}]	5	2	2024-07-01
52	9	Entreprise SARL	2	[{"changed": {"fields": ["Image url"]}}]	5	2	2024-07-01
53	9	Entreprise SARL	2	[{"changed": {"fields": ["Image url"]}}]	5	2	2024-07-01
54	9	Entreprise SARL	2	[{"changed": {"fields": ["Image url"]}}]	5	2	2024-07-01
55	9	Entreprise SARL	2	[{"changed": {"fields": ["Image url"]}}]	5	2	2024-07-01
56	8	KOKOJOB	2	[{"changed": {"fields": ["Image url"]}}]	5	2	2024-07-01
57	10	JOJO Company	1	[{"added": {}}]	5	2	2024-07-01
58	10	JOJO Company	2	[{"changed": {"fields": ["Date end"]}}]	5	2	2024-07-01
59	10	JOJO Company	2	[{"changed": {"fields": ["Status"]}}]	5	2	2024-07-01
60	10	JOJO Company	2	[{"changed": {"fields": ["Status", "Date end"]}}]	5	2	2024-07-01
61	10	JOJO Company	2	[{"added": {"name": "novel image", "object": "Image for JOJO Company"}}, {"added": {"name": "novel image", "object": "Image for JOJO Company"}}]	5	2	2024-07-01
62	9	Entreprise SARL	2	[{"added": {"name": "novel image", "object": "Image for Entreprise SARL"}}, {"added": {"name": "novel image", "object": "Image for Entreprise SARL"}}, {"added": {"name": "novel image", "object": "Image for Entreprise SARL"}}]	5	2	2024-07-01
63	8	KOKOJOB	2	[{"added": {"name": "novel image", "object": "Image for KOKOJOB"}}, {"added": {"name": "novel image", "object": "Image for KOKOJOB"}}]	5	2	2024-07-01
64	9	Entreprise SARL	2	[{"changed": {"fields": ["Date end"]}}]	5	2	2024-07-02
65	9	Entreprise SARL	2	[{"changed": {"fields": ["Status"]}}]	5	2	2024-07-02
66	9	Entreprise SARL	2	[{"changed": {"fields": ["Brief description"]}}]	5	2	2024-07-03
67	11	Taxi Voiture de Luxe	1	[{"added": {}}, {"added": {"name": "novel image", "object": "Image for Taxi Voiture de Luxe"}}, {"added": {"name": "novel image", "object": "Image for Taxi Voiture de Luxe"}}]	5	2	2024-07-03
68	12	Network Base	1	[{"added": {}}, {"added": {"name": "novel image", "object": "Image for Network Base"}}]	5	2	2024-07-03
69	12	Network Base	2	[]	5	2	2024-07-04
70	12	Network Base	2	[]	5	2	2024-07-04
71	12	Network Base	2	[]	5	2	2024-07-04
72	11	Taxi Voiture de Luxe	2	[{"changed": {"fields": ["Status"]}}]	5	2	2024-07-04
73	12	Network Base	2	[]	5	2	2024-07-04
74	12	Network Base	2	[{"changed": {"fields": ["Status"]}}]	5	2	2024-07-04
75	12	Network Base	2	[{"changed": {"fields": ["Status"]}}]	5	2	2024-07-04
76	11	Taxi Voiture de Luxe	2	[{"changed": {"fields": ["Status"]}}]	5	2	2024-07-04
77	12	Network Base	2	[{"changed": {"fields": ["Status"]}}]	5	2	2024-07-04
78	11	Taxi Voiture de Luxe	2	[{"changed": {"fields": ["Status"]}}]	5	2	2024-07-04
79	12	Network Base	2	[{"changed": {"fields": ["Status"]}}]	5	2	2024-07-04
80	12	Network Base	2	[{"changed": {"fields": ["Status", "Date end"]}}]	5	2	2024-07-04
81	11	Taxi Voiture de Luxe	2	[{"changed": {"fields": ["Date start"]}}]	5	2	2024-07-04
82	12	Network Base	2	[{"changed": {"fields": ["Date end"]}}]	5	2	2024-07-04
83	11	Taxi Voiture de Luxe	2	[{"changed": {"fields": ["Date end"]}}]	5	2	2024-07-04
84	12	Network Base	2	[{"changed": {"fields": ["Date end"]}}]	5	2	2024-07-04
85	12	Network Base	2	[]	5	2	2024-07-04
86	12	Network Base	2	[{"changed": {"fields": ["Status", "Date end"]}}]	5	2	2024-07-04
87	11	Taxi Voiture de Luxe	2	[{"changed": {"fields": ["Status", "Date end"]}}]	5	2	2024-07-04
88	12	Network Base	2	[]	5	2	2024-07-04
89	13	Chips Potatoes Miam	1	[{"added": {}}]	5	2	2024-07-05
90	14	Frite aux poulets	1	[{"added": {}}]	5	2	2024-07-05
91	14	Frite aux poulets	2	[]	5	2	2024-07-05
92	15	JOJO Company	1	[{"added": {}}]	5	2	2024-07-05
93	14	Frite aux poulets	2	[{"added": {"name": "novel image", "object": "Image for Frite aux poulets"}}]	5	2	2024-07-05
94	13	Chips Potatoes Miam	3		5	2	2024-07-05
95	14	Frite aux poulets	3		5	2	2024-07-05
96	15	JOJO Company	3		5	2	2024-07-05
97	16	Chips Potatoes Miam	1	[{"added": {}}, {"added": {"name": "novel image", "object": "Image for Chips Potatoes Miam"}}]	5	2	2024-07-05
98	17	Frite aux poulets	1	[{"added": {}}, {"added": {"name": "novel image", "object": "Image for Frite aux poulets"}}, {"added": {"name": "novel image", "object": "Image for Frite aux poulets"}}]	5	2	2024-07-05
99	18	iPhone 15	1	[{"added": {}}, {"added": {"name": "novel image", "object": "Image for iPhone 15"}}, {"added": {"name": "novel image", "object": "Image for iPhone 15"}}, {"added": {"name": "novel image", "object": "Image for iPhone 15"}}]	5	2	2024-07-05
100	19	Nitendo Switch	1	[{"added": {}}, {"added": {"name": "novel image", "object": "Image for Nitendo Switch"}}]	5	2	2024-07-05
101	19	Nitendo Switch	2	[{"added": {"name": "novel image", "object": "Image for Nitendo Switch"}}, {"added": {"name": "novel image", "object": "Image for Nitendo Switch"}}, {"added": {"name": "novel image", "object": "Image for Nitendo Switch"}}]	5	2	2024-07-05
\.


--
-- Data for Name: _django_content_type; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._django_content_type (id, app_label, model) FROM stdin;
6	admin	logentry
8	auth	group
7	auth	permission
9	contenttypes	contenttype
1	novel	category
2	novel	country
5	novel	novel
11	novel	novelimage
4	novel	town
3	novel	user
10	sessions	session
\.


--
-- Data for Name: _django_migrations; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2024-06-14
2	contenttypes	0002_remove_content_type_name	2024-06-14
3	auth	0001_initial	2024-06-14
4	auth	0002_alter_permission_name_max_length	2024-06-14
5	auth	0003_alter_user_email_max_length	2024-06-14
6	auth	0004_alter_user_username_opts	2024-06-14
7	auth	0005_alter_user_last_login_null	2024-06-14
8	auth	0006_require_contenttypes_0002	2024-06-14
9	auth	0007_alter_validators_add_error_messages	2024-06-14
10	auth	0008_alter_user_username_max_length	2024-06-14
11	auth	0009_alter_user_last_name_max_length	2024-06-14
12	auth	0010_alter_group_name_max_length	2024-06-14
13	auth	0011_update_proxy_permissions	2024-06-14
14	auth	0012_alter_user_first_name_max_length	2024-06-14
15	novel	0001_initial	2024-06-14
16	admin	0001_initial	2024-06-14
17	admin	0002_logentry_remove_auto_add	2024-06-14
18	admin	0003_logentry_add_action_flag_choices	2024-06-14
19	sessions	0001_initial	2024-06-14
20	novel	0002_novel_location_novel_mail_contact_and_more	2024-06-17
21	novel	0003_novel_novel_number_novel_number	2024-07-01
22	novel	0004_remove_novel_image_url_alter_novel_novel_number_and_more	2024-07-01
23	novel	0005_alter_novelimage_image_url	2024-07-05
24	novel	0006_alter_novelimage_image_url	2024-07-05
\.


--
-- Data for Name: _django_session; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._django_session (session_key, session_data, expire_date) FROM stdin;
oeluddw9647ni7mnxhhl6vrdywgw9u5p	.eJxVjEEOwiAQRe_C2pBCgbEu3fcMZJgZpWogKe3KeHfbpAvd_vfef6uI65Lj2mSOE6uLsur0uyWkp5Qd8APLvWqqZZmnpHdFH7TpsbK8rof7d5Cx5a0GI46tT34ASdZDzwbsObAhCIOwM94zS0edQ4I-kANBujEGb7aSnPp8AdlDOAI:1sOESx:XjPjbSR8e83Ud3V8HjxuNBpgRF5U7PauoS5jskVfVsM	2024-07-15
\.


--
-- Data for Name: _novel_category; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._novel_category (id, name) FROM stdin;
1	Jobs
2	Location
3	Services
4	A vendre
5	Evénnements
6	Nourritures
\.


--
-- Data for Name: _novel_category_town; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._novel_category_town (id, category_id, town_id) FROM stdin;
1	1	1
2	1	2
3	1	3
4	1	4
5	1	5
6	1	6
7	1	7
8	1	8
9	1	9
10	2	1
11	2	2
12	2	3
13	2	4
14	2	7
15	3	1
16	3	2
17	3	3
18	3	4
19	3	6
20	3	7
21	3	8
22	4	1
23	4	2
24	4	3
25	4	4
26	4	5
27	4	6
28	4	7
29	4	8
30	4	9
31	5	1
32	5	2
33	5	3
35	5	5
36	5	6
37	5	7
38	5	8
39	6	1
40	6	2
41	6	3
42	6	4
43	6	5
44	6	6
45	6	7
46	6	8
47	6	9
\.


--
-- Data for Name: _novel_country; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._novel_country (id, name) FROM stdin;
1	Bénin
2	Togo
3	Nigéria
\.


--
-- Data for Name: _novel_novel; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._novel_novel (id, name, brief_description, description, status, date_start, date_end, category_id, country_id, town_id, location, mail_contact, phone_contact, novel_number, number) FROM stdin;
3	Kom Service	Vente de Come	Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil natus, tenetur ducimus cum suscipit inventore eaque, consequuntur officiis facere sunt debitis illo fugiat pariatur et in? Maxime nulla id sit.	1			4	2	4	https://map.google.com	com.services@gmail.com	(+229)0000000000		1
4	CAR Location	Vente véhicule de luxe	Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil natus, tenetur ducimus cum suscipit inventore eaque, consequuntur officiis facere sunt debitis illo fugiat pariatur et in? Maxime nulla id sit.	1			2	3	8	https://map.google.com	example.service@gmail.com	(+229)0000000000		1
5	Porto Grill	Patisserie Boulangerie	Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil natus, tenetur ducimus cum suscipit inventore eaque, consequuntur officiis facere sunt debitis illo fugiat pariatur et in? Maxime nulla id sit.	1			6	1	2	https://map.google.com	porto-grill@live.com	(+229)0000000000	2024070300000001	1
6	HOUSE SERVICE	Appartement à louer	Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil natus, tenetur ducimus cum suscipit inventore eaque, consequuntur officiis facere sunt debitis illo fugiat pariatur et in? Maxime nulla id sit.	1			2	1	3	https://map.google.com	service.house@hormai.com	(+229)0000000000	2024070300000001	1
7	Delicious Meals	Restaurant Nigeria Food	Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quisquam, sapiente ullam soluta ab autem a neque ipsam inventore aliquid necessitatibus quas consequuntur tempora iste corrupti temporibus architecto nostrum, non odio!	1			6	3	7	https://map.google.com	meal.meal@gmail.com	(+229)0000000000		1
8	KOKOJOB	Job Desc	Some text goes here	0			1	1	1	https://google.map	example.service@gmail.com	(+229)0000000000	2024070100000001	1
9	Entreprise SARL	Besoin d'un ingénieur réseau.	Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil natus, tenetur ducimus cum suscipit inventore eaque, consequuntur officiis facere sunt debitis illo fugiat pariatur et in? Maxime nulla id sit.	1			1	1	1	https://map.google.com	entreprise.sarl@gmail.com	(+229)66008384	2024070100000002	2
10	JOJO Company	Besoin d'un ingénieur réseau.	Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil natus, tenetur ducimus cum suscipit inventore eaque, consequuntur officiis facere sunt debitis illo fugiat pariatur et in? Maxime nulla id sit.	1			1	1	1	https://map.google.com	jojo@gmail.com	(+229)0000000000	2024070100000003	3
11	Taxi Voiture de Luxe	Service TAXI en voiture de Luxe	Nous vous offrons un service de taxi en voiture de luxe. Durant tout ce mois d'Octobre à seulement 1000 f CFA le trajet peut importe votre distance dans la ville de Porto-Novo.\r\n\r\nContactez nous pour plus d'informations.\r\n\r\nNos coordonnées sont disponibles sur le site.\r\n\r\nTél: +229 787777777 | Mail: taxi.service@gmail.com	0			3	1	2	https://map.google.com	taxi.service@gmail.com	(+229)787777777	2024070300000004	4
12	Network Base	Administrateur Reseau	Some text goes here	0			1	1	2	https://map.google.com/	example.service@gmail.com	(+229)0000000000	2024070300000005	5
16	Chips Potatoes Miam	Chips de pomme de terre à vendre	Nous vous offrons des chips de pomme de terre à seulement 1000 f CFA dans Cotonou.\r\n\r\nContactez nous pour plus d'informations.\r\n\r\nNos coordonnées sont disponibles sur le site.\r\n\r\nTél: +229 787777777 | Mail: example.service@gmail.com	0			4	1	1	https://map.google.com	example.service@gmail.com	(+229)0000000000	2024070500000006	6
17	Frite aux poulets	Plat de résistance consistant	Nous vous offrons des chips des plats de résistance aux Frites aux poulets à seulement 1000 f CFA dans Cotonou.\r\n\r\nContactez nous pour plus d'informations.\r\n\r\nNos coordonnées sont disponibles sur le site.\r\n\r\nTél: +229 787777777 | Mail: example.service@gmail.com	0			4	1	1	https://map.google.com	example.service@gmail.com	(+229)0000000000	2024070500000007	7
18	iPhone 15	iPhone 15 venue Neuf	JE vend un iPhone 15 pour 800.000 f CFA\r\nContact 3456775654	0			4	1	1	https://mapl.google.com	example.service@gmail.com	(+229)0000000000	2024070500000008	8
19	Nitendo Switch	Nitendo Switch - Console Unique	Vente Nitendo Switch Console unique sans les JoyCons	0			4	1	1	https://mapl.google.com/	entreprise.sarl@gmail.com	(+229)0000000000	2024070500000009	9
\.


--
-- Data for Name: _novel_novelimage; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._novel_novelimage (id, "interval", novel_id, image_url) FROM stdin;
1	6000	10	/static/novel/imgs/
2	5000	10	/static/novel/imgs/
3	4000	9	/static/novel/imgs/
4	10000	9	/static/novel/imgs/
5	7000	9	/static/novel/imgs/
6	2000	8	/static/novel/imgs/
7	5000	8	/static/novel/imgs/
8	5000	11	/static/novel/imgs/
9	5000	11	/static/novel/imgs/
10	5000	12	/static/novel/imgs/
12	5000	16	/static/novel/imgs/
13	5000	17	/static/novel/imgs/
14	5000	17	/static/novel/imgs/
15	5000	18	/static/novel/imgs/
16	6000	18	/static/novel/imgs/
17	3000	18	/static/novel/imgs/
18	5000	19	/static/novel/imgs/
19	6000	19	/static/novel/imgs/
20	8000	19	/static/novel/imgs/
21	3000	19	/static/novel/imgs/
\.


--
-- Data for Name: _novel_town; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._novel_town (id, name, country_id) FROM stdin;
1	Cotonou	1
2	Porto-Novo	1
3	Calavi	1
4	Lomé	2
5	Sokodé	2
6	Kara	2
7	Lagos	3
8	Abuja	3
9	Kano	3
\.


--
-- Data for Name: _novel_user; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._novel_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, wallet) FROM stdin;
1	pbkdf2_sha256$720000$gPCyPCcRiqsWjuA4ktXXVC$EQlR8wkKcQ7qj+Q0kHuD70U+SMTtSboZ34FWKnNmoEs=	2024-06-17	1	netron90			fredyannra@gmail.com	1	1	2024-06-14	0
2	pbkdf2_sha256$720000$B2mnMHNFCzwq7tmLnFnhlo$tMGLD1aDSA2oyLesZD2Alrzj5IGqiOOjpiNoChmHoXk=	2024-07-01	1	yann			yann@example.com	1	1	2024-07-01	0
\.


--
-- Data for Name: _novel_user_groups; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._novel_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: _novel_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._novel_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: _sqlite_sequence; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._sqlite_sequence (name, seq) FROM stdin;
django_migrations	24
django_content_type	11
auth_permission	44
auth_group	0
django_admin_log	101
novel_user	2
novel_country	3
novel_town	9
novel_category	6
novel_category_town	47
novel_novel	19
novel_novelimage	21
\.


--
-- PostgreSQL database dump complete
--

